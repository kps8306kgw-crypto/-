프로젝트 일정 관리 Android 앱 소스

연동 방식
- Android 시스템 파일 선택기를 사용합니다.
- OneDrive Android 앱이 설치되고 로그인되어 있으면 파일 선택기의 OneDrive 위치에서 프로젝트 프로그램의 data/project_manager.db를 선택할 수 있습니다.
- 최초 선택 후 읽기 권한을 저장합니다.
- 앱의 새로고침 버튼을 누르면 OneDrive DB를 다시 내려받아 최신 내용을 표시합니다.
- 안전을 위해 이 Android 버전은 조회 전용입니다. Windows 프로그램과 Android가 동시에 SQLite DB를 직접 수정하면 파일 충돌이나 DB 손상이 발생할 수 있습니다.

확인 가능 화면
- 전체 프로젝트 대시보드
- 프로젝트별 주간 기록, 예상 플랜, 실제 한일, 이슈
- 프로젝트 일정 목록 및 계획/실제 간트
- 시험 일정 목록 및 계획/실제 간트
- 프로젝트 시작일 기준 주차 날짜

빌드
1. Android Studio Ladybug 이상에서 ProjectManagerAndroid 폴더를 엽니다.
2. Android SDK 35를 설치합니다.
3. Gradle Sync 후 Build > Build APK(s)를 실행합니다.
4. 생성 APK: app/build/outputs/apk/debug/app-debug.apk

주의
- 이 패키지는 Android Studio 소스 프로젝트입니다. 현재 실행 환경에는 Android SDK가 없어 APK 바이너리는 포함하지 못했습니다.
- OneDrive 공유 링크를 하드코딩하지 않고 Android의 공식 Storage Access Framework를 사용하므로 개인/회사 OneDrive에서 모두 사용할 수 있고 Azure 앱 등록이 필요 없습니다.
